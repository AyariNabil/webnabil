package tn.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tn.spring.entity.PeriodeScp_Fon;

@Repository
public interface PeriodeScp_FonRepostiory extends JpaRepository<PeriodeScp_Fon, Long> {

}
