package tn.spring.RequestApiForm;

import javax.validation.constraints.NotBlank;
import java.util.List;

public class FondDTO {

    private long id ;
    @NotBlank(message = "Denomination is mandatory")
    private String denomination_fonds;
    private List<PeriodeDTO> periodes;

    public FondDTO() {
    }

    public FondDTO(long id, String denomination_fonds, List<PeriodeDTO> periodes) {
        this.id = id;
        this.denomination_fonds = denomination_fonds;
        this.periodes = periodes;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDenomination_fonds() {
        return denomination_fonds;
    }

    public void setDenomination_fonds(String denomination_fonds) {
        this.denomination_fonds = denomination_fonds;
    }

    public List<PeriodeDTO> getPeriodes() {
        return periodes;
    }

    public void setPeriodes(List<PeriodeDTO> periodes) {
        this.periodes = periodes;
    }
}
