package tn.spring.RequestApiForm;

import tn.spring.entity.Souscription;

public class EditSouscriptionRequest {

    private  Souscription souscription ;

    private Long souscripteurId ;


    public EditSouscriptionRequest() {

    }
    public EditSouscriptionRequest(Souscription souscription, Long souscripteurId) {
        this.souscription = souscription;
        this.souscripteurId = souscripteurId;
    }


    public Souscription getSouscription() {
        return souscription;
    }

    public void setSouscription(Souscription souscription) {
        this.souscription = souscription;
    }

    public Long getSouscripteurId() {
        return souscripteurId;
    }

    public void setSouscripteurId(Long souscripteurId) {
        this.souscripteurId = souscripteurId;
    }
}
