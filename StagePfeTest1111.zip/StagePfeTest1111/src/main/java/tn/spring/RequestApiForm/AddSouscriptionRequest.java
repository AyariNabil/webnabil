package tn.spring.RequestApiForm;

import jakarta.persistence.Entity;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;
import org.springframework.web.bind.annotation.CrossOrigin;
import tn.spring.entity.Souscription;

import java.util.Date;

@Data
public class AddSouscriptionRequest {

	private int souscripteur_id ;
   private Souscription souscription ;

	public AddSouscriptionRequest() {

	}


	public AddSouscriptionRequest(int souscripteur_id, Souscription souscription) {
		this.souscripteur_id = souscripteur_id;
		this.souscription = souscription;
	}

	public int getSouscripteur_id() {
		return souscripteur_id;
	}

	public void setSouscripteur_id(int souscripteur_id) {
		this.souscripteur_id = souscripteur_id;
	}

	public Souscription getSouscription() {
		return souscription;
	}

	public void setSouscription(Souscription souscription) {
		this.souscription = souscription;
	}
}
