package tn.spring.RequestApiForm;

import javax.validation.constraints.NotNull;
import java.util.Date;

public class PeriodeDTO {

    private Long id ;
    @NotNull(message = "Periode Debut is mandatory")
    private Date periodeDebut;
    @NotNull(message = "Periode Fin is mandatory")
    private Date periodeFin;

    public PeriodeDTO() {
    }

    public PeriodeDTO(Long id, Date periodeDebut, Date periodeFin) {
        this.id = id;
        this.periodeDebut = periodeDebut;
        this.periodeFin = periodeFin;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getPeriodeDebut() {
        return periodeDebut;
    }

    public void setPeriodeDebut(Date periodeDebut) {
        this.periodeDebut = periodeDebut;
    }

    public Date getPeriodeFin() {
        return periodeFin;
    }

    public void setPeriodeFin(Date periodeFin) {
        this.periodeFin = periodeFin;
    }
}
