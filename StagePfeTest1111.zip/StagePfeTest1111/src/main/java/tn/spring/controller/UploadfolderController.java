package tn.spring.controller;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.util.StringUtils;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.spring.entity.DossierFond;
import tn.spring.entity.Fond;
import tn.spring.repository.DossierFondRepository;
import tn.spring.repository.FondRepository;
import tn.spring.service.UploadFolderService;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@RequestMapping("/folder")
@RestController
public class UploadfolderController {
    @Autowired
    private FondRepository fondRepository;
    @Autowired
    private DossierFondRepository dossierFondRepository ;

    @Autowired
    private UploadFolderService uploadFolderService ;

    @PostMapping("/ajouterdossier/{id}")
    public ResponseEntity<DossierFond> ajouterDossier(@PathVariable Long id, @RequestParam String nomDossier) {
        Fond fond = fondRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Fond introuvable avec l'ID : " + id));

        DossierFond dossier = new DossierFond();
        dossier.setNom(nomDossier);
        dossier.setFond(fond);

        DossierFond dossierEnregistre = dossierFondRepository.save(dossier);

        if (!StringUtils.isNullOrEmpty(nomDossier)) {
            // call the createFolderInS3Bucket method from the UploadFolderService class
            uploadFolderService.createFolderInS3Bucket("test1", nomDossier);
        }

        return ResponseEntity.ok(dossierEnregistre);
    }




    @GetMapping("/{id}/dossiers")
    public ResponseEntity<List<String>> afficherNomsDossiersFond(@PathVariable long id) {
        Fond fond = fondRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Fond introuvable avec l'ID : " + id));

        List<DossierFond> dossiers = fond.getDossiers();
        List<String> nomsDossiers = new ArrayList<>();

        for (DossierFond dossier : dossiers) {
            nomsDossiers.add(dossier.getNom());
        }

        return ResponseEntity.ok(nomsDossiers);
    }




}
