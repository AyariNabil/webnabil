package tn.spring.controller;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tn.spring.RequestApiForm.AddSouscriptionRequest;
import tn.spring.RequestApiForm.EditSouscriptionRequest;
import tn.spring.entity.Souscripteur;
import tn.spring.entity.Souscription;
import tn.spring.repository.SouscripteurRepository;
import tn.spring.repository.SouscriptionRepository;
import tn.spring.service.SouscripteurService;
import tn.spring.service.SouscriptionService;
import tn.spring.service.UploadFileService;


@RestController
@RequestMapping("/souscription")
@CrossOrigin
public class SouscriptionController {
    
    @Autowired
    private SouscriptionService souscriptionService;
    @Autowired
    private SouscripteurService souscripteurService;
	private Souscripteur souscripteur;
    @Autowired
    private SouscripteurRepository souscripteurRepo ;

    @Autowired
    private SouscriptionRepository SOUSCRIPTIONRepo ;

    @Autowired
    private UploadFileService fileService ;


    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {
        File file = new File(multipartFile.getOriginalFilename());
        FileOutputStream outputStream = new FileOutputStream(file);
        outputStream.write(multipartFile.getBytes());
        outputStream.close();
        return file;
    }

    @PostMapping("/Create-s")
    public Souscription CreateEvent(@RequestBody AddSouscriptionRequest  souscriptionRequest) throws ParseException, IOException {
        Souscripteur souscripteur = null ;

        souscripteur = souscripteurService.getSouscripteurId((long) souscriptionRequest.getSouscripteur_id());

        Souscription eventToSave = new Souscription();
        eventToSave.setMontant_de_souscription(souscriptionRequest.getSouscription().getMontant_de_souscription());




        eventToSave.setDate_de_soucription(souscriptionRequest.getSouscription().getDate_de_soucription());
        eventToSave.setSouscripteur(souscripteur);
        System.out.println(souscripteur);

        return    souscriptionService.create(eventToSave); // Persist the event ;


    }










    @PostMapping("/upload-and-create-souscription")
    public String handleFileUploadAndCreateSouscription(@RequestParam("file") MultipartFile file, @RequestBody AddSouscriptionRequest souscriptionRequest) throws ParseException, IOException {
        if (!file.isEmpty()) {
            try {
                String fileName = file.getOriginalFilename();
                File file1 = convertMultipartFileToFile(file);

                fileService.uploadFileToS3Bucket("test", fileName, file1);

                Souscripteur souscripteur = null;
                souscripteur = souscripteurService.getSouscripteurId((long) souscriptionRequest.getSouscripteur_id());

                Souscription eventToSave = new Souscription();
                eventToSave.setMontant_de_souscription(souscriptionRequest.getSouscription().getMontant_de_souscription());
                eventToSave.setDate_de_soucription(souscriptionRequest.getSouscription().getDate_de_soucription());
                eventToSave.setSouscripteur(souscripteur);

                souscriptionService.create(eventToSave); // Persist the souscription ;

                return "File uploaded and Souscription created successfully";
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return "File upload and Souscription creation failed";
    }


        @PutMapping("/update/{id}")
        public Souscription updateEvent (@PathVariable Long id, @RequestBody EditSouscriptionRequest event){
            return this.souscriptionService.update_Event(id, event);
        }


        @GetMapping("/getall")
        List<Souscription> getAll () {

            return souscriptionService.getAll();
        }


        @GetMapping("/getbyid/{id}")
        public ResponseEntity<Souscription> getSouscriptionById (@PathVariable Long id){
            Souscription souscription = souscriptionService.getSouscriptionById(id);
            return new ResponseEntity<Souscription>(souscription, HttpStatus.OK);
        }


        @DeleteMapping("delete/{id}")
        public ResponseEntity<Void> deleteSouscriptionById (@PathVariable Long id){
            souscriptionService.delete(id);
            return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
        }


    }
