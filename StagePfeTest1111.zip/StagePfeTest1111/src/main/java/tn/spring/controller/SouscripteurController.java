package tn.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.spring.entity.Souscripteur;
import tn.spring.service.SouscripteurService;

@RestController
@RequestMapping("/souscripteur")
@CrossOrigin
public class SouscripteurController {
	   @Autowired
	    private SouscripteurService Souscripteur_service;

	   @DeleteMapping("/delete/{id}")
	   void delete(@PathVariable Long id)
	   {
		   Souscripteur_service.delete(id);
	   }
	   @PostMapping("/create")
	   Souscripteur create(@RequestBody Souscripteur s)
		{

			return Souscripteur_service.create(s);
		}

		@Transactional
	   @PutMapping("/update/{id}")
		Souscripteur update(@RequestBody Souscripteur s ,@PathVariable Long id)
		{
			return Souscripteur_service.update(s , id);
		}

	    @GetMapping("/getall")
		List<Souscripteur> getAll(){
			
		return	Souscripteur_service.getAll();
		}

}
