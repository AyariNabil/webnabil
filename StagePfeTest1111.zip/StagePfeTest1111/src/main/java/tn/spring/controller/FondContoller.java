package tn.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.spring.RequestApiForm.FondDTO;
import tn.spring.RequestApiForm.PeriodeDTO;
import tn.spring.entity.Fond;
import tn.spring.entity.PeriodeScp_Fon;
import tn.spring.repository.FondRepository;
import tn.spring.repository.PeriodeScp_FonRepostiory;
import tn.spring.service.FondService;

import javax.validation.Valid;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/fond")
public class FondContoller {

    @Autowired
    private FondService fondService;
    @Autowired
    private  FondRepository fondRepository ;

    @Autowired
    PeriodeScp_FonRepostiory periodeRepository;



    @GetMapping("/AfficherFond")
    public ResponseEntity<List<Fond>> getAllFonds() {
        List<Fond> fonds = fondService.getAllFonds();
        return new ResponseEntity<>(fonds, HttpStatus.OK);
    }

    @GetMapping("/{fondId}")
    public ResponseEntity<Fond> getFondById(@PathVariable Long fondId) {
        Fond fond = fondService.getFondById(fondId);
        if(fond != null) {
            return new ResponseEntity<>(fond, HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/AjouterFond")
    public Fond ajouterFond(@RequestBody Fond fond) throws ParseException
        {
            Fond nouveauFond = fondRepository.save(fond);

            // Associer les périodes au fond
            if (fond.getPeriodes() != null) {
                for (PeriodeScp_Fon periode : nouveauFond.getPeriodes()) {
                    periode.setFond(nouveauFond);
                    try {
                        periodeRepository.save(periode);
                    } catch (IllegalStateException e) {
                        // Log the error or return an appropriate error response
                        e.printStackTrace();
                    }
                }
            }

            return fondRepository.save(nouveauFond);
        }








    }





  //  @PostMapping("/AjouterFond")
   // public ResponseEntity<Fond> ajouterFond(@RequestBody Fond fond) {
        //Fond nouveauFond = fondRepository.save(fond);

        // Associer les périodes au fond
       // if (fond.getPeriodes() != null) {
        //    for (PeriodeScp_Fon periode : nouveauFond.getPeriodes()) {
           //     periode.setFond(nouveauFond);
           //     periodeRepository.save(periode);
          //  }
     //   }

     //   return new ResponseEntity<>(nouveauFond, HttpStatus.CREATED);
  //  }











