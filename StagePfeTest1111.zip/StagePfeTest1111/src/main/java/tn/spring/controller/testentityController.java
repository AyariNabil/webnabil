package tn.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tn.spring.entity.Testentity;
import tn.spring.repository.TestentityRepostiory;
import tn.spring.service.UploadFileService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;

@RestController
@RequestMapping("/test")
public class testentityController {

    @Autowired
    private UploadFileService fileService;

    @Autowired
    private TestentityRepostiory testrepo;

    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {
        File file = new File(multipartFile.getOriginalFilename());
        FileOutputStream outputStream = new FileOutputStream(file);
        outputStream.write(multipartFile.getBytes());
        outputStream.close();
        return file;
    }

    @PostMapping("/Create-T")
    public String CreateTest(@RequestParam("file") MultipartFile file, @RequestBody Testentity testentity) throws ParseException, IOException {


       testrepo.save(testentity);

        String fileName = file.getOriginalFilename() + "_" + testentity.getId();
              File file1 = convertMultipartFileToFile(file);

              fileService.uploadFileToS3Bucket("test", fileName, file1);
               return "File uploaded successfully";


    }
}

