package tn.spring.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import tn.spring.entity.FichierSouscription;
import tn.spring.entity.Souscription;
import tn.spring.repository.FichierSouscriptionRepository;
import tn.spring.repository.SouscriptionRepository;
import tn.spring.service.SouscripteurService;
import tn.spring.service.SouscriptionService;
import tn.spring.service.UploadFileService;

import java.util.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


@RequestMapping("/file1")
@RestController
public class UploadfileController {


    @Autowired
    private UploadFileService fileService ;
    @Autowired

    private SouscriptionRepository SOUSCRIPTIONRepo ;
    @Autowired

    private SouscriptionService sousservice ;
    @Autowired
    private FichierSouscriptionRepository fichierSouscriptionRepository;


    private String Namefolder = "nabilo1" ;



    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {
        File file = new File(multipartFile.getOriginalFilename());
        FileOutputStream outputStream = new FileOutputStream(file);
        outputStream.write(multipartFile.getBytes());
        outputStream.close();
        return file;
    }



    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file) {
        if (!file.isEmpty()) {
            try {
                String fileName = file.getOriginalFilename();

                File file1 = convertMultipartFileToFile(file);


                fileService.uploadFileToS3Bucket("test" , fileName , file1);
                return "File uploaded successfully";
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return "File upload failed";
    }


    @PostMapping("/{id}/ajouterfichieradiscription")
    @ResponseBody
    public ResponseEntity<?> ajouterFichier(@PathVariable Long id, @RequestParam("fichier") MultipartFile fichier) throws IOException {
        Souscription souscription = sousservice.getSouscriptionById(id);

        String extension = FilenameUtils.getExtension(fichier.getOriginalFilename());
        String uniqueName = UUID.randomUUID().toString() + "." + extension;
        String nomFichier = FilenameUtils.getBaseName(fichier.getOriginalFilename()) + "_" + souscription.getId() + "_" + uniqueName;

        File fichierLocal = convertMultipartFileToFile(fichier);

        // Enregistrer le fichier dans S3/Minio

        fileService.uploadFileToS3Bucket("test", nomFichier, fichierLocal);

        // Créer une entité FichierSouscription pour ce fichier
        FichierSouscription fichierSouscription = new FichierSouscription();
        fichierSouscription.setNom(nomFichier);
        fichierSouscription.setSouscription(souscription);

        souscription.setFichiersouscription(fichierSouscription);
        fichierSouscriptionRepository.save(fichierSouscription);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Fichier ajouté avec succès");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }



    @GetMapping("/{id}/fichier")
    public ResponseEntity<String> getFichierSouscriptionNom(@PathVariable Long id) throws JsonProcessingException {
        Optional<FichierSouscription> optionalFichierSouscription = fichierSouscriptionRepository.findById(id);
        if (optionalFichierSouscription.isPresent()) {
            FichierSouscription fichierSouscription = optionalFichierSouscription.get();
            String nom = fichierSouscription.getNom();
            if (nom != null && !nom.isEmpty()) {
                ObjectMapper objectMapper = new ObjectMapper();
                String json = objectMapper.writeValueAsString(nom);
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                return new ResponseEntity<>(json, headers, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("pas de fichier", HttpStatus.OK);
            }
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Fichier de souscription introuvable");
        }
    }





    @GetMapping("/download/{nomFichier}")
    public ResponseEntity<byte[]> downloadFichierS3(@PathVariable String nomFichier) throws IOException {
        byte[] data = fileService.downloadFileFromS3Bucket("test", nomFichier);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", nomFichier);
        headers.setContentLength(data.length);
        return new ResponseEntity<>(data, headers, HttpStatus.OK);
    }


}

























