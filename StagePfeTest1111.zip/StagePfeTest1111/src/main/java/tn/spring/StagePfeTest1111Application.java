package tn.spring;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class StagePfeTest1111Application {

	public static void main(String[] args) {
		SpringApplication.run(StagePfeTest1111Application.class, args);


	}


}
