package tn.spring.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Date;

@Entity
public class PeriodeScp_Fon {

    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private Long id ;
    @Temporal(TemporalType.DATE)
    private Date periodeDebut;
    @Temporal(TemporalType.DATE)
    private Date periodeFin;
    @ManyToOne
    @JsonIgnore
    private Fond fond;

    public PeriodeScp_Fon() {
    }

    public PeriodeScp_Fon(Long id, Date periodeDebut, Date periodeFin, Fond fond) {
        this.id = id;
        this.periodeDebut = periodeDebut;
        this.periodeFin = periodeFin;
        this.fond = fond;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getPeriodeDebut() {
        return periodeDebut;
    }

    public void setPeriodeDebut(Date periodeDebut) {
        this.periodeDebut = periodeDebut;
    }

    public Date getPeriodeFin() {
        return periodeFin;
    }

    public void setPeriodeFin(Date periodeFin) {
        this.periodeFin = periodeFin;
    }

    public Fond getFond() {
        return fond;
    }

    public void setFond(Fond fond) {
        this.fond = fond;
    }












}

