package tn.spring.entity;

import java.util.ArrayList;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;


@Entity
public class Souscripteur  {
	
	    @Id
	    @GeneratedValue(strategy =  GenerationType.IDENTITY)

	    private Long id;

	    private String name;

	
	    private String etablissement;

	    private String nationalite;
	    private String categoriepart;


	    
		@JsonIgnore
		@OneToMany(mappedBy = "souscripteur")
		 List<Souscription> souscriptions = new ArrayList<Souscription>();
	public Souscripteur() {
		super();
	}
		public Souscripteur(Long id, String name, String etablissement, String nationalite, String categoriepart,
				List<Souscription> souscriptions) {
			super();
			this.id = id;
			this.name = name;
			this.etablissement = etablissement;
			this.nationalite = nationalite;
			this.categoriepart = categoriepart;
			this.souscriptions = souscriptions;
		}



		public Long getId() {
         return id ;
  		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getEtablissement() {
			return etablissement;
		}

		public void setEtablissement(String etablissement) {
			this.etablissement = etablissement;
		}

		public String getNationalite() {
			return nationalite;
		}

		public void setNationalite(String nationalite) {
			this.nationalite = nationalite;
		}

		public String getCategoriepart() {
			return categoriepart;
		}

		public void setCategoriepart(String categoriepart) {
			this.categoriepart = categoriepart;
		}

		public List<Souscription> getSouscriptions() {
			return souscriptions;
		}

		public void setSouscriptions(List<Souscription> souscriptions) {
			this.souscriptions = souscriptions;
		}

		
		
		
		
		
		
		
		
		
		
		
	    
	    
	


}
