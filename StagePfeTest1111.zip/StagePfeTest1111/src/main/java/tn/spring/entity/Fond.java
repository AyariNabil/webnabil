package tn.spring.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Date;
import java.util.List;

@Entity

public class Fond {

    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private long id ;

    private String  denomination_fonds ;

    private double  montantF;

    private  int dureeF;

    @Temporal(TemporalType.DATE)

    private  Date dateCreation;
    @Temporal(TemporalType.DATE)

    private  Date date_obtention_Visa;

    private String n_Visa;


    private String banqueDepo ;

    private  float frais_depositaire;

    private  float frais_Gestion ;

    private  String nature_Fonds;

    private  String forme_Legal;




    private String cadres_investi;

    //Taux pour le calcul des ratios réglementaires:


    private double ratio_reglementaire ;

    private double ratio_regl_souscripteurs ;


    //Taux pour le calcul des ratios de conformité:

    private double ratio_par_secteur ;

    private double ratio_par_societe ;

    private  double ratio_Quasi_fonds ;

    private double ratio_de_conformite ;

    private double ratio_investis_marche ;


    private String etat ;

    @Temporal(TemporalType.DATE)

    @OneToMany(mappedBy = "fond")
    private List<PeriodeScp_Fon> periodes;


    @OneToMany(mappedBy = "fond")
    private List<DossierFond> dossiers;

    public Fond() {
    }

    public Fond(long id, String denomination_fonds, double montantF, int dureeF, Date dateCreation, Date date_obtention_Visa, String n_Visa, String banqueDepo, float frais_depositaire, float frais_Gestion, String nature_Fonds, String forme_Legal, String cadres_investi, double ratio_reglementaire, double ratio_regl_souscripteurs, double ratio_par_secteur, double ratio_par_societe, double ratio_Quasi_fonds, double ratio_de_conformite, double ratio_investis_marche, String etat, List<PeriodeScp_Fon> periodes, List<DossierFond> dossiers) {
        this.id = id;
        this.denomination_fonds = denomination_fonds;
        this.montantF = montantF;
        this.dureeF = dureeF;
        this.dateCreation = dateCreation;
        this.date_obtention_Visa = date_obtention_Visa;
        this.n_Visa = n_Visa;
        this.banqueDepo = banqueDepo;
        this.frais_depositaire = frais_depositaire;
        this.frais_Gestion = frais_Gestion;
        this.nature_Fonds = nature_Fonds;
        this.forme_Legal = forme_Legal;
        this.cadres_investi = cadres_investi;
        this.ratio_reglementaire = ratio_reglementaire;
        this.ratio_regl_souscripteurs = ratio_regl_souscripteurs;
        this.ratio_par_secteur = ratio_par_secteur;
        this.ratio_par_societe = ratio_par_societe;
        this.ratio_Quasi_fonds = ratio_Quasi_fonds;
        this.ratio_de_conformite = ratio_de_conformite;
        this.ratio_investis_marche = ratio_investis_marche;
        this.etat = etat;
        this.periodes = periodes;
        this.dossiers = dossiers;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDenomination_fonds() {
        return denomination_fonds;
    }

    public void setDenomination_fonds(String denomination_fonds) {
        this.denomination_fonds = denomination_fonds;
    }

    public double getMontantF() {
        return montantF;
    }

    public void setMontantF(double montantF) {
        this.montantF = montantF;
    }

    public int getDureeF() {
        return dureeF;
    }

    public void setDureeF(int dureeF) {
        this.dureeF = dureeF;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Date getDate_obtention_Visa() {
        return date_obtention_Visa;
    }

    public void setDate_obtention_Visa(Date date_obtention_Visa) {
        this.date_obtention_Visa = date_obtention_Visa;
    }

    public String getN_Visa() {
        return n_Visa;
    }

    public void setN_Visa(String n_Visa) {
        this.n_Visa = n_Visa;
    }

    public String getBanqueDepo() {
        return banqueDepo;
    }

    public void setBanqueDepo(String banqueDepo) {
        this.banqueDepo = banqueDepo;
    }

    public float getFrais_depositaire() {
        return frais_depositaire;
    }

    public void setFrais_depositaire(float frais_depositaire) {
        this.frais_depositaire = frais_depositaire;
    }

    public float getFrais_Gestion() {
        return frais_Gestion;
    }

    public void setFrais_Gestion(float frais_Gestion) {
        this.frais_Gestion = frais_Gestion;
    }

    public String getNature_Fonds() {
        return nature_Fonds;
    }

    public void setNature_Fonds(String nature_Fonds) {
        this.nature_Fonds = nature_Fonds;
    }

    public String getForme_Legal() {
        return forme_Legal;
    }

    public void setForme_Legal(String forme_Legal) {
        this.forme_Legal = forme_Legal;
    }

    public String getCadres_investi() {
        return cadres_investi;
    }

    public void setCadres_investi(String cadres_investi) {
        this.cadres_investi = cadres_investi;
    }

    public double getRatio_reglementaire() {
        return ratio_reglementaire;
    }

    public void setRatio_reglementaire(double ratio_reglementaire) {
        this.ratio_reglementaire = ratio_reglementaire;
    }

    public double getRatio_regl_souscripteurs() {
        return ratio_regl_souscripteurs;
    }

    public void setRatio_regl_souscripteurs(double ratio_regl_souscripteurs) {
        this.ratio_regl_souscripteurs = ratio_regl_souscripteurs;
    }

    public double getRatio_par_secteur() {
        return ratio_par_secteur;
    }

    public void setRatio_par_secteur(double ratio_par_secteur) {
        this.ratio_par_secteur = ratio_par_secteur;
    }

    public double getRatio_par_societe() {
        return ratio_par_societe;
    }

    public void setRatio_par_societe(double ratio_par_societe) {
        this.ratio_par_societe = ratio_par_societe;
    }

    public double getRatio_Quasi_fonds() {
        return ratio_Quasi_fonds;
    }

    public void setRatio_Quasi_fonds(double ratio_Quasi_fonds) {
        this.ratio_Quasi_fonds = ratio_Quasi_fonds;
    }

    public double getRatio_de_conformite() {
        return ratio_de_conformite;
    }

    public void setRatio_de_conformite(double ratio_de_conformite) {
        this.ratio_de_conformite = ratio_de_conformite;
    }

    public double getRatio_investis_marche() {
        return ratio_investis_marche;
    }

    public void setRatio_investis_marche(double ratio_investis_marche) {
        this.ratio_investis_marche = ratio_investis_marche;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public List<PeriodeScp_Fon> getPeriodes() {
        return periodes;
    }

    public void setPeriodes(List<PeriodeScp_Fon> periodes) {
        this.periodes = periodes;
    }

    public List<DossierFond> getDossiers() {
        return dossiers;
    }

    public void setDossiers(List<DossierFond> dossiers) {
        this.dossiers = dossiers;
    }
}


