package tn.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.spring.entity.Fond;
import tn.spring.entity.PeriodeScp_Fon;
import tn.spring.repository.FondRepository;

import java.util.List;
import java.util.Optional;

@Service
public class FondService {

    @Autowired
    private FondRepository fondRepository;
    private PeriodeScp_Fon prdRepository ;


    public List<Fond> getAllFonds() {
        return fondRepository.findAll();
    }


    public Fond getFondById(Long fondId) {
        Optional<Fond> fond = fondRepository.findById(fondId);
        if(fond.isPresent()) {
            return fond.get();
        }
        else {
            return null;
        }
    }


    public Fond saveFond(Fond fond) {


        return fondRepository.save(fond);
    }


    public void deleteFond(Long fondId) {
        fondRepository.deleteById(fondId);
    }


}
