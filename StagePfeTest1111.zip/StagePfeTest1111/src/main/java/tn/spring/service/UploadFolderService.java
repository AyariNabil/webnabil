package tn.spring.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.spring.entity.DossierFond;
import tn.spring.entity.Fond;
import tn.spring.repository.FondRepository;

import java.io.ByteArrayInputStream;
import java.util.List;

@Service
public class UploadFolderService {


    @Autowired
    private AmazonS3 s3Client;



    @Autowired
    private FondRepository fondRepository;







    public void createFolderInS3Bucket(String bucketName, String folderName) {
        String folderKey = folderName + "/";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(0L);
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, folderKey, inputStream, objectMetadata);
        s3Client.putObject(putObjectRequest);
    }

}
