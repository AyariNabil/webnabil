package tn.spring.service;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.*;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;


@Service
public class UploadFileService {
    @Autowired
    private AmazonS3 s3Client;




    public void uploadFileToS3Bucket(String bucketName , String key ,  File file ) {
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, key, file);
        s3Client.putObject(putObjectRequest);
    }

    public byte[] downloadFileFromS3Bucket(String bucketName, String fileName) {

        S3Object s3object = null;
        try {
            s3object = s3Client.getObject(bucketName, fileName);

            // Lire le contenu du fichier et le stocker dans un tableau de bytes
            S3ObjectInputStream inputStream = s3object.getObjectContent();
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, len);
            }
            byte[] fileContent = outputStream.toByteArray();

            return fileContent;
        } catch (AmazonServiceException e) {
            throw new RuntimeException("Erreur lors du téléchargement du fichier à partir de Amazon S3 : " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException("Erreur lors de la lecture du contenu du fichier : " + e.getMessage());
        } finally {
            if (s3object != null) {
                try {
                    s3object.close();
                } catch (IOException e) {
                    throw new RuntimeException("Erreur lors de la fermeture de l'objet S3 : " + e.getMessage());
                }
            }
        }
    }


    public void createFolderInS3Bucket(String bucketName, String folderName) {
        String folderKey = folderName + "/";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(new byte[0]);
        ObjectMetadata objectMetadata = new ObjectMetadata();
        objectMetadata.setContentLength(0L);
        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, folderKey, inputStream, objectMetadata);
        s3Client.putObject(putObjectRequest);
    }







}
