package tn.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.spring.RequestApiForm.EditSouscriptionRequest;
import tn.spring.entity.Souscripteur;
import tn.spring.entity.Souscription;
import tn.spring.repository.SouscripteurRepository;
import tn.spring.repository.SouscriptionRepository;



@Service
public class SouscriptionService {
	
	@Autowired
	SouscriptionRepository souscriptionrepository;
	SouscripteurRepository souscripteurrepository;
	
	public void delete(Long id) {
		// TODO Auto-generated method stub
		souscriptionrepository.deleteById(id);
	}


	public Souscription create(Souscription s) {
		// TODO Auto-generated method stub
		return souscriptionrepository.save(s);
	}
	public Souscription update_Event(Long id, EditSouscriptionRequest request) {
		Souscription souscripteur = souscriptionrepository.findById(request.getSouscripteurId()).orElse(null);
		if (souscripteur == null) {
			// gérer le cas où l'objet n'est pas présent
		}

		Souscription souscription = souscriptionrepository.findById(id).orElse(null);
		if (souscription == null) {
			// gérer le cas où l'objet n'est pas présent
		}

		souscription.setMontant_de_souscription(request.getSouscription().getMontant_de_souscription());
		souscription.setDate_de_soucription(request.getSouscription().getDate_de_soucription());
		souscription.setSouscripteur(souscripteur.getSouscripteur());

		return souscriptionrepository.save(souscription);
	}





	public List<Souscription> getAll() {
		// TODO Auto-generated method stub
		return souscriptionrepository.findAll();
	}


	public Souscription getSouscriptionById(Long id) {
		// TODO Auto-generated method stub
		return souscriptionrepository.findById(id).get();
	}

	
	
	
}
