import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Souscripteur } from '../models/souscripteur';
import { Souscription } from '../models/souscription';
import { SouscripteurService } from '../services/souscripteur.service';
import { SouscriptionService } from '../services/souscription.service';

@Component({
  selector: 'app-ajoutersouscription',
  templateUrl: './ajoutersouscription.component.html',
  styleUrls: ['./ajoutersouscription.component.css']
})
export class AjoutersouscriptionComponent implements OnInit {




  
  souscripteurs: Souscripteur[]=[];
  souscription: Souscription = new Souscription ;

  constructor(private souscripteurService: SouscripteurService , private souscriptionService: SouscriptionService,
              private router:Router) { }

  ngOnInit(): void {
    this.getAllSouscripteurs();
  }


  getAllSouscripteurs(){
    this.souscripteurService.list().subscribe( res =>{
        this.souscripteurs = res;
        console.log(res);
      },
      (error: HttpErrorResponse ) => {
        alert(error.message);
      });
  }


  addsouscription()  {

    let data = this.souscription;
    console.log(data);
    data.date_de_soucription=this.souscription.date_de_soucription
    

    let request:any={
      "souscription":this.souscription,
      "souscripteur_id":this.souscription.souscripteur_id
    }
    console.log(request);
    this.souscriptionService.addSouscription(request).subscribe( res =>{
        this.redirectTo("/souscription");
      },
      (error: HttpErrorResponse ) => {
        alert(error.message);
      });
  }
  redirectTo(uri:string){
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
      this.router.navigate([uri]));
  }
  



}
