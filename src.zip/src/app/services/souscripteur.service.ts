import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Souscripteur } from '../models/souscripteur';

@Injectable({
  providedIn: 'root'
})
export class SouscripteurService {
 
  productURL = environment.apiResURL + '/souscripteur';
  constructor(private httpClient : HttpClient) { }

  public list(): Observable<Souscripteur[]>{
    return this.httpClient.get<Souscripteur[]>(`${this.productURL}/getall`);

  }

  public detail(id: number): Observable<Souscripteur>{
    return this.httpClient.get<Souscripteur>(`${this.productURL}/GetById/${id}`);
    }


    public create (souscripteur:Souscripteur):Observable<Souscripteur>{

      return this.httpClient.post<Souscripteur>(`${this.productURL}/create`,souscripteur);
    }


    public delete(id: number): Observable<Souscripteur>{


       return this.httpClient.delete<any>(`${this.productURL}/delete` + `/${id}` );
    }


}
