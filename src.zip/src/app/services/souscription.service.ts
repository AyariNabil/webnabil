import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Souscription } from '../models/souscription';
@Injectable({
  providedIn: 'root'
})
export class SouscriptionService {


  productURL = environment.apiResURL + '/souscription';
  constructor(private httpClient : HttpClient) { }

  public list(): Observable<Souscription[]>{
    return this.httpClient.get<Souscription[]>(`${this.productURL}/getall`);
    
  }


  public addSouscription(request : any): Observable<any>{
    return this.httpClient.post<any>(`${this.productURL}/Create-s`, request);

  }


  
  public delete(id: number): Observable<Souscription>{


    return this.httpClient.delete<any>(`${this.productURL}/delete` + `/${id}` );
 }
    

}
