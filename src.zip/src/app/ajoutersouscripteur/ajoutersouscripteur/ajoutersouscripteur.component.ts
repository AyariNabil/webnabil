import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Souscripteur } from 'src/app/models/souscripteur';
import { SouscripteurService } from 'src/app/services/souscripteur.service';


@Component({
  selector: 'app-ajoutersouscripteur',
  templateUrl: './ajoutersouscripteur.component.html',
  styleUrls: ['./ajoutersouscripteur.component.css']
})
export class AjoutersouscripteurComponent implements OnInit{

  souscripteur : Souscripteur = new Souscripteur();


 constructor( 
  private souscripteurservice: SouscripteurService,
  private toast: ToastrService,
  private route: ActivatedRoute,

  

  
  ) {}

  ngOnInit(): void {
 

    }

   
  


    addsous() {
      

      console.log(this.souscripteur);
      this.souscripteurservice.create(this.souscripteur).subscribe( res =>{
          this.redirectTo("/souscripteur");
          //this.souscripteurservice.list();
      
        },
        (error: HttpErrorResponse ) => {
          alert(error.message);
        });
    }
  redirectTo(arg0: string) {
    throw new Error('Method not implemented.');
  }}




