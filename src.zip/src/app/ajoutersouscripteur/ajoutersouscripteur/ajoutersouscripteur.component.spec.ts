import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutersouscripteurComponent } from './ajoutersouscripteur.component';

describe('AjoutersouscripteurComponent', () => {
  let component: AjoutersouscripteurComponent;
  let fixture: ComponentFixture<AjoutersouscripteurComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjoutersouscripteurComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjoutersouscripteurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
