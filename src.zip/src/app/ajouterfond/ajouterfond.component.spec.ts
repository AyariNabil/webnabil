import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjouterfondComponent } from './ajouterfond.component';

describe('AjouterfondComponent', () => {
  let component: AjouterfondComponent;
  let fixture: ComponentFixture<AjouterfondComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjouterfondComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjouterfondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
