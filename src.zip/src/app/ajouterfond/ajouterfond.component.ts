import { Component, OnInit } from '@angular/core';

declare var bootstrap: any;

@Component({
  selector: 'app-ajouterfond',
  templateUrl: './ajouterfond.component.html',
  styleUrls: ['./ajouterfond.component.css']
})
export class AjouterfondComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    const modalToggleSelect: HTMLSelectElement | null = document.getElementById('modal-toggle-select') as HTMLSelectElement;
    const modal = new bootstrap.Modal(document.getElementById('exampleModal'));

    modalToggleSelect?.addEventListener('change', () => {
      if (modalToggleSelect.value === 'open-modal') {
        modal.show();
      }
    });
  }

}
