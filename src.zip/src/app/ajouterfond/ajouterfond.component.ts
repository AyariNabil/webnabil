import { Component, OnInit } from '@angular/core';

declare var bootstrap: any;

@Component({
  selector: 'app-ajouterfond',
  templateUrl: './ajouterfond.component.html',
  styleUrls: ['./ajouterfond.component.css']
})
export class AjouterfondComponent implements OnInit {
  selectedCategory: string = 'Libre';
  constructor() { }

  ngOnInit(): void {

  }

}
