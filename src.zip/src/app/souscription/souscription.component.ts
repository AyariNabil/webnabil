import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Souscription } from '../models/souscription';
import { SouscriptionService } from '../services/souscription.service';

@Component({
  selector: 'app-souscription',
  templateUrl: './souscription.component.html',
  styleUrls: ['./souscription.component.css']
})
export class SouscriptionComponent implements OnInit {
  souscriptions: Souscription[] = []
  firstname: any;

  constructor(
    private souscriptionservice: SouscriptionService,
    private toast: ToastrService,
    private route: ActivatedRoute,
    private router: Router,




  ) {

  }




  ngOnInit(): void {
    this.getSouscriptions();

  }





  getSouscriptions(): void {

    this.souscriptionservice.list().subscribe(

      data => {

        this.souscriptions = data;
        console.log(data);


      },
      err => {

        this.toast.error(err.error.message, 'Error', { timeOut: 3000, positionClass: 'toast-top-center' });
      }


    );



  }

 



  onDelete(id: any) {
    this.souscriptionservice.delete(id).subscribe(res =>{
      this.getSouscriptions();
    },(error : HttpErrorResponse) =>{
      alert(error.message);
    });
  }
redirectTo(arg0: string) {
  throw new Error('Method not implemented.');
}




  Serach() {
    if (this.firstname != "") {
      this.souscriptions = this.souscriptions.filter(res => {

        return res.souscripteur?.name?.toLocaleLowerCase().includes(this.firstname.toLocaleLowerCase())
        || res.montant_de_souscription?.toString().includes(this.firstname.toLocaleLowerCase());
      
      });

    } else if (this.firstname == "")
    {this.ngOnInit();}

   
  }
}
