import { Component, Input, OnInit } from '@angular/core';
import { Souscripteur } from '../models/souscripteur';
import { ToastrService } from 'ngx-toastr';
import { SouscripteurService } from '../services/souscripteur.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-souscripteur',
  templateUrl: './souscripteur.component.html',
  styleUrls: ['./souscripteur.component.css']
})
export class SouscripteurComponent implements OnInit {
 souscripteurs: Souscripteur[]= []
 firstname : any;


 constructor( 
  private souscripteurservice: SouscripteurService,
  private toast: ToastrService,
  private route: ActivatedRoute,
  private router: Router,
  
  ) {

}


 
  
    ngOnInit(): void {
    this.getSouscripteurs();
    }


    
   
   
    getSouscripteurs(): void {

      this.souscripteurservice.list().subscribe(
  
        data =>{

             this.souscripteurs= data ;

       
          },
          err=>{
       
           this.toast.error(err.error.message , 'Error' , { timeOut : 3000 , positionClass : 'toast-top-center'});
          }
       
       
         );
  
  
  
  
    }

    onDelete(id: any) {
      this.souscripteurservice.delete(id).subscribe(res =>{
        this.getSouscripteurs();
      },(error : HttpErrorResponse) =>{
        alert(error.message);
      });
    }
  redirectTo(arg0: string) {
    throw new Error('Method not implemented.');
  }



  Serach() {
    if (this.firstname != "") {
      this.souscripteurs = this.souscripteurs.filter(res => {

        return res.name?.toLocaleLowerCase().includes(this.firstname.toLocaleLowerCase())
        || res.etablissement?.toLocaleLowerCase().includes(this.firstname.toLocaleLowerCase());
      
      });

    } else if (this.firstname == "")
    {this.ngOnInit();}

   
  }

  }