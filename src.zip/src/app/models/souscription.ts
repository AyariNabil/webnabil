import { Souscripteur } from "./souscripteur";

export class Souscription {
    id!: number;
    montant_de_souscription: number | undefined;
    date_de_soucription: Date | undefined;
    souscripteur_id: number | undefined;
    souscripteur: Souscripteur | undefined;



    /*{ id : number,
      name : string , 
      etablissement : String ,
      nationalite:String,
      categoriepart: String}
  
  }*/
}
  