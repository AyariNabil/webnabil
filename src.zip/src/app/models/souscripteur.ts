export class Souscripteur {

    id!: number;
    name: string | undefined;
    etablissement: string | undefined;
    nationalite: string | undefined;
    categoriepart: string | undefined;

   
}
