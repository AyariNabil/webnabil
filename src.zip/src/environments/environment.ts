export const environment = {
  production: false,
  apiResURL:'http://localhost:8089'
}