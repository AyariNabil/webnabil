package tn.spring.controller;



import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import tn.spring.RequestApiForm.AddSouscriptionRequest;
import tn.spring.entity.Souscripteur;
import tn.spring.entity.Souscription;
import tn.spring.repository.SouscripteurRepository;
import tn.spring.repository.SouscriptionRepository;
import tn.spring.service.SouscripteurService;
import tn.spring.service.SouscriptionService;


@RestController
@RequestMapping("/souscription")
@CrossOrigin
public class SouscriptionController {
    
    @Autowired
    private SouscriptionService souscriptionService;
    @Autowired
    private SouscripteurService souscripteurService;
	private Souscripteur souscripteur;
    @Autowired
    private SouscripteurRepository souscripteurRepo ;

    @Autowired
    private SouscriptionRepository SOUSCRIPTIONRepo ;

    @PostMapping("/Create-s")
    public Souscription CreateEvent(@RequestBody AddSouscriptionRequest  souscriptionRequest) throws ParseException {
        Souscripteur souscripteur = null ;

        souscripteur = souscripteurService.getSouscripteurId((long) souscriptionRequest.getSouscripteur_id());

        Souscription eventToSave = new Souscription();
        eventToSave.setMontant_de_souscription(souscriptionRequest.getSouscription().getMontant_de_souscription());




        eventToSave.setDate_de_soucription(souscriptionRequest.getSouscription().getDate_de_soucription());
        eventToSave.setSouscripteur(souscripteur);
        System.out.println(souscripteur);


        return    souscriptionService.create(eventToSave); // Persist the event ;


    }





    @GetMapping("/getall")
    List<Souscription> getAll(){

        return	souscriptionService.getAll();
    }


    @GetMapping("/getbyid/{id}")
    public ResponseEntity<Souscription> getSouscriptionById(@PathVariable Long id) {
        Souscription souscription = souscriptionService.getSpaceById(id);
        return new ResponseEntity<Souscription>(souscription, HttpStatus.OK);
    }
    
    
    

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteSouscriptionById(@PathVariable Long id) {
        souscriptionService.delete(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
}
