package tn.spring.entity;


import jakarta.persistence.*;


import java.util.Date;


@Entity
public class Souscription {
	    
	
	
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	private Long id;
	


	private int montant_de_souscription;


	@Temporal(TemporalType.DATE)
	private Date date_de_soucription;






	@ManyToOne
	Souscripteur souscripteur;

	public Souscription() {
		super();
	}


	public Souscription(Long id, int montant_de_souscription, Date date_de_soucription, Souscripteur souscripteur) {
		this.id = id;
		this.montant_de_souscription = montant_de_souscription;
		this.date_de_soucription = date_de_soucription;
		this.souscripteur = souscripteur;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getMontant_de_souscription() {
		return montant_de_souscription;
	}

	public void setMontant_de_souscription(int montant_de_souscription) {
		this.montant_de_souscription = montant_de_souscription;
	}

	public Date getDate_de_soucription() {


		return date_de_soucription;
	}

	public void setDate_de_soucription(Date date_de_soucription) {
		this.date_de_soucription = date_de_soucription;
	}

	public Souscripteur getSouscripteur() {
		return souscripteur;
	}

	public void setSouscripteur(Souscripteur souscripteur) {
		this.souscripteur = souscripteur;
	}
}
