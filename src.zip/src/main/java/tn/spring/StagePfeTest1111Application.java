package tn.spring;

import com.twilio.rest.chat.v2.service.Binding;
import org.apache.chemistry.opencmis.client.SessionParameterMap;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
@SpringBootApplication
public class StagePfeTest1111Application {

	public static void main(String[] args) {
		SpringApplication.run(StagePfeTest1111Application.class, args);


	}


	public void createFolderInAlfresco(String folderName) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String alfrescoUrl = "http://localhost:8080/alfresco/api/-default-/public/alfresco/versions/1/nodes/-root-/children";
		String jsonRequest = "{\"name\":\"" + folderName + "\",\"nodeType\":\"cm:folder\"}";

		HttpEntity<String> requestEntity = new HttpEntity<String>(jsonRequest, headers);
		String response = restTemplate.postForObject(alfrescoUrl, requestEntity, String.class);
		System.out.println("Folder created in Alfresco: " + folderName);
	}
}
