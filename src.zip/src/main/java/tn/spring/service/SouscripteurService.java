package tn.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.spring.entity.Souscripteur;
import tn.spring.repository.SouscripteurRepository;

@Service
public class SouscripteurService {

	@Autowired
	SouscripteurRepository souscripteurrepository;
	
	public void delete(Long id) {
		// TODO Auto-generated method stub
		souscripteurrepository.deleteById(id);
	}


	public Souscripteur create(Souscripteur s) {
		// TODO Auto-generated method stub
		return souscripteurrepository.save(s);
	}

	public Souscripteur update(Souscripteur s, Long id) {
		// TODO Auto-generated method stub
		s.setId(id);
		return souscripteurrepository.save(s);
	}


	public List<Souscripteur> getAll() {
		// TODO Auto-generated method stub
		return souscripteurrepository.findAll();
	}


	public Souscripteur getSouscripteurId(Long id) {
		// TODO Auto-generated method stub
		return souscripteurrepository.findById(id).get();
	}
}
