package tn.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.spring.entity.Fond;
import tn.spring.entity.Souscription;
import tn.spring.repository.FondRepository;
import tn.spring.repository.SouscriptionRepository;

import java.util.List;

@Service
public class FondService {

    @Autowired
    FondRepository Fondrp;

    public void delete(Long id) {
        // TODO Auto-generated method stub
        Fondrp.deleteById(id);
    }


    public Fond create(Fond s) {
        // TODO Auto-generated method stub
        return Fondrp.save(s);
    }

    public Fond update(Fond s, Long id) {
        // TODO Auto-generated method stub

        return Fondrp.save(s);
    }


    public List<Fond> getAll() {
        // TODO Auto-generated method stub
        return Fondrp.findAll();
    }


    public Fond getSpaceById(Long id) {
        // TODO Auto-generated method stub
        return Fondrp.findById(id).get();
    }
}
