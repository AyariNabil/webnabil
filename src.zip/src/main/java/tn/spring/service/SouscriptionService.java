package tn.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import tn.spring.entity.Souscripteur;
import tn.spring.entity.Souscription;
import tn.spring.repository.SouscripteurRepository;
import tn.spring.repository.SouscriptionRepository;



@Service
public class SouscriptionService {
	
	@Autowired
	SouscriptionRepository souscriptionrepository;
	
	public void delete(Long id) {
		// TODO Auto-generated method stub
		souscriptionrepository.deleteById(id);
	}


	public Souscription create(Souscription s) {
		// TODO Auto-generated method stub
		return souscriptionrepository.save(s);
	}

	public Souscription update(Souscription s, Long id) {
		// TODO Auto-generated method stub
		s.setId(id);
		return souscriptionrepository.save(s);
	}


	public List<Souscription> getAll() {
		// TODO Auto-generated method stub
		return souscriptionrepository.findAll();
	}


	public Souscription getSpaceById(Long id) {
		// TODO Auto-generated method stub
		return souscriptionrepository.findById(id).get();
	}

	
	
	
}
